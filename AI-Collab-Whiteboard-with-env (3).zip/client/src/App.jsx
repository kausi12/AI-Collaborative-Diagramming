import React, { useState } from 'react'
import CanvasBoard from './components/CanvasBoard'

export default function App() {
  const [roomId, setRoomId] = useState('main-room')
  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-5xl mx-auto">
        <header className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-semibold">AI Collab Whiteboard</h1>
          <div>
            <label className="mr-2">Room:</label>
            <input value={roomId} onChange={e=>setRoomId(e.target.value)} className="border px-2 py-1 rounded" />
          </div>
        </header>
        <CanvasBoard roomId={roomId} />
      </div>
    </div>
  )
}